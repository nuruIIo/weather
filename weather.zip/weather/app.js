const api = "ca4a2c6f649b1676424e3416da2fe05a";
const input = document.querySelector("#input");
const cityOf = document.querySelector("#city");
const weath = document.querySelector("#celsi");
const main = document.querySelector("#main");
const overcast = document.querySelector("#overcast");
const windSpeed = document.querySelector("#wind-speed");
const feels = document.querySelector("#feels-like");
const humidity = document.querySelector("#humidity");

async function fetchData() {
  try {
    let city = input.value || "Tashkent";

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${api}`;
    const response = await fetch(url);

    const data = await response.json();
    const temperatureCelsius = (data.main.temp - 273.15).toFixed(0);

    cityOf.innerHTML = `Weather in ${city}`;
    weath.innerHTML = `${temperatureCelsius}°C`;
    weath.style.fontSize = "5rem";
    windSpeed.innerHTML = `Wind Speed: ${data.wind.speed} m/s`;
    feels.innerHTML = `Feels Like: ${(data.main.feels_like - 273.15).toFixed(
      0
    )}°C`;
    humidity.innerHTML = `Humidity: ${data.main.humidity}%`;
    overcast.innerHTML = `Condition: ${data.weather[0].description}`;

    switch (data.weather[0].main) {
      case "Clouds":
        main.innerHTML = "☁️";
        break;
      case "Clear":
        main.innerHTML = "☀️";
        break;
      case "Light rain":
      case "Rain":
        main.innerHTML = "🌧️";
        break;
      case "Snow":
      case "Light snow":
        main.innerHTML = "❄️";
        break;
      case "Sunny":
        main.innerHTML = "🌞";
        break;
      case "Smoke":
      case "Mist":
      case "Fog":
        main.innerHTML = "💨";
        break;
      default:
        main.innerHTML = "";
    }

    main.style.fontSize = "6rem";

    console.log(data);
  } catch (error) {
    console.error(error);
  }
}

input.addEventListener("keypress", function (event) {
  if (event.key === "Enter") {
    fetchData();
  }
});

fetchData();
